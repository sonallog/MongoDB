from pymongo import MongoClient

try:
    client=MongoClient("mongodb://sonal:mongodb15@ac-fg7ryuq-shard-00-00.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-01.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-02.gohglxk.mongodb.net:27017/?ssl=true&replicaSet=atlas-en48vp-shard-0&authSource=admin&retryWrites=true&w=majority")
    db=client.office
    coll=db["workers"]
    
    dep=input("Enter department : ")
    dic={}
    dic["dept"]=dep
    print(dic)

    for doc in coll.find(dic):
        print(doc)

except Exception as e:
    print(e)


