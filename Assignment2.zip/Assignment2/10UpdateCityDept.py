from pymongo import MongoClient

try:
    client=MongoClient("mongodb://sonal:mongodb15@ac-fg7ryuq-shard-00-00.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-01.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-02.gohglxk.mongodb.net:27017/?ssl=true&replicaSet=atlas-en48vp-shard-0&authSource=admin&retryWrites=true&w=majority")
    db=client.office
    coll=db["workers"]

    dic={}
    id=int(input("enter employee ID : "))
    dic["_id"]=id
    print(dic)

    ct={}
    city=input("Enter new City : ")
    ct["city"]=city
    print(ct)

    dp={}
    dep=input("Enter new Department : ")
    dp["dept"]=dep
    print(dp)

    upct={"$set":ct}
    coll.update_one(dic,upct)
    print('document updated')

    updp={"$set":dp}
    coll.update_one(dic,updp)
    print("document updated")
    

except Exception as e:
    print(e)
