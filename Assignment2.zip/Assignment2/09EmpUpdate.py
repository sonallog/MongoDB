from pymongo import MongoClient

try:
    client=MongoClient("mongodb://sonal:mongodb15@ac-fg7ryuq-shard-00-00.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-01.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-02.gohglxk.mongodb.net:27017/?ssl=true&replicaSet=atlas-en48vp-shard-0&authSource=admin&retryWrites=true&w=majority")
    db=client.office
    coll=db["workers"]

    qr={}
    id=int(input("enter employee ID : "))
    qr["_id"]=id
    print(qr)

    ch={}
    salary=float(input('Enter new salary : '))
    ch["sal"]=salary
    print(ch)

    up={"$set":ch}
    coll.update_one(qr,up)
    print('document updated')

    upsal={}
    id=int(input("Enter employee id : "))
    upsal["_id"]=id
    print(upsal)

    for doc in coll.find(upsal):
        print(doc)


except Exception as e:
    print(e)
