from pymongo import MongoClient

try:
    client=MongoClient('mongodb://sonal:mongodb15@ac-fg7ryuq-shard-00-00.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-01.gohglxk.mongodb.net:27017,ac-fg7ryuq-shard-00-02.gohglxk.mongodb.net:27017/?ssl=true&replicaSet=atlas-en48vp-shard-0&authSource=admin&retryWrites=true&w=majority')
    db=client.office
    coll=db["workers"]

    eid=int(input("Enter employee ID : "))
    empnm=input("Enter name : ")
    dept=input("Enter department : ")
    post=input("Enter post : ")
    city=input("Enter city : ")
    sal=float(input("Enter salary : "))
    mob=int(input("Enter a mob number : "))
    email=input("Enter a email : " )

    dic={}
    dic["_id"]=eid
    dic["name"]=empnm
    dic["dept"]=dept
    dic["post"]=post
    dic["city"]=city
    dic["sal"]=sal
    dic["mob"]=mob
    dic["email"]=email
    print(dic)

    coll.insert_one(dic)
    print('Document inserted to cloud database')
except Exception as e:
    print(e)
